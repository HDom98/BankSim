To start choose between a customer or a manager. The program reads from either the csv files or a txt file.
The files contain all the account names which are needed to use the customer choice.
the manager allows you to see all the balances of a certain persons account or all the accounts.