/*
Hugo Dominguez
Robin
September 28, 2019
CS 3331
Daniel Mejia
programming assignment 2
a program that reads a text file and allows the user to inquire,deposit,withdraw,and pay someone using 
the text file.

I confirm that the work of this assignment is completely my own. By turning in this assignment, 
I declare that I did not receive unauthorized assistance. Moreover, all deliverables including, 
but not limited to the source code, lab report, and output files were written and produced by me alone.
*/
package people;

import java.io.IOException;

public abstract class Person {
	private String firstName;
    private String lastName;
    private String birthday;
    private String id;
    private String address;
    private String phoneNum;

    /**
     * Constructor
     * @param firstName
     * @param lastName
     * @param birthday
     * @param id
     * @param address
     * @param phoneNum
     */
    public Person(String firstName,String lastName,String birthday,String id,String address,String phoneNum){
        this.firstName=firstName;
        this.lastName=lastName;
        this.birthday=birthday;
        this.id=id;
        this.address=address;
        this.phoneNum=phoneNum;
    }
    public Person(){}

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getBirthday() {
        return this.birthday;
    }

    public String getId() {
        return this.id;
    }

    public String getAddress() {
        return this.address;
    }

    public String getPhoneNum() {
        return this.phoneNum;
    }

    /**
     * abstract class to pay a person
     * @param person1
     * @param person2
     * @param amount
     * @throws IOException
     */
    abstract public void payPerson(Customer person1,Customer person2,double amount) throws IOException;
}
