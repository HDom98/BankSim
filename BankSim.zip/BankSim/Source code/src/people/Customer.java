package people;

import java.io.IOException;
import accounts.*;

public class Customer extends Person {
	public Checking checkingAcc;
	public Saving savingsAcc;
	public Credit creditAcc;

	/**
	 * Constructor. Assumes that every customer has a Checking, Savings, and Credit
	 * account
	 * 
	 * @param firstName
	 * @param lastName
	 * @param birthday
	 * @param id
	 * @param address
	 * @param phoneNum
	 * @param checkingAcc
	 * @param savingsAcc
	 * @param creditAcc
	 */
	public Customer(String firstName, String lastName, String birthday, String id, String address, String phoneNum,
			Checking checkingAcc, Saving savingsAcc, Credit creditAcc) {
		super(firstName, lastName, birthday, id, address, phoneNum);
		this.checkingAcc = checkingAcc;
		this.savingsAcc = savingsAcc;
		this.creditAcc = creditAcc;
	}

	/**
	 * Method that allows for one customer to pay another as long as the amount they
	 * pay isnt greater than their balance in their Checking account
	 * 
	 * @param person1
	 * @param person2
	 * @param amount
	 */
	public void payPerson(Customer person1, Customer person2, double amount) throws IOException {
		if (amount < person1.checkingAcc.getBalance()) {
			double balance1 = person1.checkingAcc.getBalance();
			double balance2 = person2.checkingAcc.getBalance();
			person1.checkingAcc.setBalance(balance1 - amount);
			person2.checkingAcc.setBalance(balance2 + amount);
		} else {
			System.out.println("Cannot transfer more than available. Please try the transaction again.");
		} // end of else
	}// end of payPerson

	public String print(){
		String print = (getFirstName()+","+getLastName()+","+getBirthday()+","+getId()+","+getAddress()
		+","+getPhoneNum()+","+checkingAcc.getAccountNum()+","+savingsAcc.getAccountNum()+","+creditAcc.getAccountNum()
		+checkingAcc.getBalance()+","+savingsAcc.getBalance()+","+creditAcc.getBalance());
		return print;
	}

}// end of class
