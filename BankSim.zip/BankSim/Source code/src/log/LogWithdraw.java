package log;

import java.io.*;
import people.*;

public class LogWithdraw implements Log {

    @Override
    public void writeLog(Customer customer, double amount, int choice) throws IOException {
    }

    /**
     * 
     * Method that writes to a log file that shows how much a customer withdrew from
     * their Checking account
     * 
     * @param customer
     * @param amount
     * @throws IOException
     */
    public void writeLog(Customer customer, double amount) throws IOException {
        File file = new File("Transaction log.txt");
        PrintWriter pw = new PrintWriter(new FileWriter(file, true));
        pw.println(customer.getFirstName() + " withdrew " + amount + " from " + customer.checkingAcc.getAccountNum());
        pw.close();
    }

}