package log;

import java.io.*;
import people.*;

public interface Log {

	public void writeLog(Customer customer, double amount, int choice) throws IOException;
}
