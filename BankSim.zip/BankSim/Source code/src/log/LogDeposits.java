package log;

import people.*;
import java.io.*;

public class LogDeposits implements Log {

    /**
     * 
     * Method that writes to a log file that contains who depoisted an amount of
     * money
     * 
     * @param customer
     * @param amount
     * @param choice
     * @throws IOException
     */
    @Override
    public void writeLog(Customer customer, double amount, int choice) throws IOException {
        File file = new File("Transaction log.txt");
        PrintWriter pw = new PrintWriter(new FileWriter(file, true));
        if (choice == 1) {
            pw.println(customer.getFirstName() + " deposited " + amount + " into Checkings account: "
                    + customer.checkingAcc.getAccountNum() + "\n");
            pw.close();
        } else if (choice == 2) {
            pw.println(customer.getFirstName() + " deposited " + amount + " into Savings account:"
                    + customer.savingsAcc.getAccountNum() + "\n");
            pw.close();
        } else if (choice == 3) {
            pw.println(customer.getFirstName() + " deposited " + amount + " into Credit account:"
                    + customer.creditAcc.getAccountNum() + "\n");
            pw.close();
        }
    }

}