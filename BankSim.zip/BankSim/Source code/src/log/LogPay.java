package log;

import people.*;
import java.io.*;

public class LogPay implements Log {
    @Override
    public void writeLog(Customer customer, double amount, int choice) throws IOException {
    }

    /**
     * 
     * Method that writes to a log file that shows customer1 paying customer2 and
     * how much they were paid
     * 
     * @param customer
     * @param customer2
     * @param amount
     * @throws IOException
     */
    public void writeLog(Customer customer, Customer customer2, double amount) throws IOException {
        File file = new File("Transaction log.txt");
        PrintWriter pw = new PrintWriter(new FileWriter(file, true));
        pw.println(customer.getFirstName() + " paid " + amount + " to " + customer2.getFirstName());
        pw.close();
    }
}