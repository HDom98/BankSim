package log;

import people.*;
import java.io.*;

public class LogInquire implements Log{
    
     /**
     * 
     * Method that writes a log file that contains who inquired a balance and on which account
     * or if a manager inquired the balance
     * @param Customer customer 
     * @param int choice
     * @throws IOException
     */
    public void writeLog(Customer customer, int choice) throws IOException {
        File file = new File("Transaction log.txt");
        PrintWriter pw = new PrintWriter(new FileWriter(file,true));

        if(choice == 1){
            pw.println(customer.getFirstName()+" inquired a balance on "+customer.checkingAcc.getAccountNum()
            +". The current balance is "+customer.checkingAcc.getBalance()+"\n");
            pw.close();
        }

        else if(choice == 2){
            pw.println(customer.getFirstName()+" inquired a balance on "+customer.savingsAcc.getAccountNum()
            +". The current balance is "+customer.savingsAcc.getBalance()+"\n");
            pw.close();
        }

        else if(choice == 3){
            pw.println(customer.getFirstName()+" inquired a balance on "+customer.creditAcc.getAccountNum()
            +". The current balance is "+customer.creditAcc.getBalance()+"\n");
            pw.close();
        }
        
        else if(choice == 4){
            pw.println("Manager inquired a balance on "+customer.getFirstName()+"'s accounts");
            pw.close();
        }
    }

    public void writeLog(Customer customer, double amount, int choice) throws IOException {  
    }
}