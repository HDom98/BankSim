package accounts;

public abstract class Account {
	 private int accountNum;
	 private double balance;
	public Account(int accountNum, double balance) {
		super();
		this.accountNum = accountNum;
		this.setBalance(balance);
	}
	
	public int getAccountNum() {
		return accountNum;
	}

	
	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance=balance;
	}


	abstract public void deposit(double amount);
	abstract public void inquire();
	abstract public void transfer(Saving savingAcc,Checking checkingAcc, Credit creditAcc, double amount,int decision);

}
