package accounts;

public class Credit extends Account {

	/**
	 * Constructor
	 * 
	 * @param accountNum
	 * @param balance
	 */
	public Credit(int accountNum, double balance) {
		super(accountNum, balance);
	}

	/**
	 * method that updates the balance with the amount entered. Assuming its not possible to get a 
	 * positive balance, the amount cannot be greater than the balance
	 * 
	 * @param amount
	 */
	// Assuming its not possible to go into the positives
	public void deposit(double amount) {
		if (amount < getBalance()) {
			setBalance(getBalance() + amount);
		} else {
			System.out.println("You're trying to deposit too much money. Please deposit less.");

		}
	}

	/**
	 * Method that allows the user to transfer money to a Checking or Savings account
	 * 
	 * @param savingAcc
	 * @param checkingAcc
	 * @param creditAcc
	 * @param amount
	 * @param decision
	 */
	@Override
	public void transfer(Saving savingAcc, Checking checkingAcc, Credit creditAcc, double amount, int decision) {
		double newBalance1;
		double newBalance2;

		switch (decision) {
		case 1:
			newBalance1 = creditAcc.getBalance() - amount;
			newBalance2 = checkingAcc.getBalance() + amount;
			checkingAcc.setBalance(newBalance1);
			savingAcc.setBalance(newBalance2);
			break;

		case 2:
			newBalance1 = checkingAcc.getBalance() - amount;
			newBalance2 = savingAcc.getBalance() + amount;
			checkingAcc.setBalance(newBalance1);
			savingAcc.setBalance(newBalance2);
			break;
		}// end of switch
	}// end of transfer

	/**
	 * Method that tells the user the balance of the account
	 */
	@Override
	public void inquire() {
		System.out.println("\nYour Credit balance is " + getBalance());

	}

	/**
	 * Method that checks if the amount provided is greater than the balance
	 * 
	 * @param amount
	 * @return Boolean
	 */
	public boolean isOverpaid(double amount) {
		boolean overpaid;
		if (amount + getBalance() > 0)
			overpaid = true;
		else
			overpaid = false;
		return overpaid;
	}
}// end of class
