package accounts;

public class Checking extends Account {

    /**
     * Constructor
     * 
     * @param accountNum
     * @param balance
     */
    public Checking(int accountNum, double balance) {
        super(accountNum, balance);
    }// end of constructor

    /**
     * Method that allows the user to withdraw money from a Checking account. If the
     * amount is greater than the current balance the user starts over
     * 
     * @param amount
     */
    public void withdraw(double amount) {
        if (amount < getBalance())
            setBalance(getBalance() - amount);
        else
            System.out.println("Cannot withdraw more than available. Please try the transaction again.");
    }// end of withdraw

    /**
     * Method that allows the user to transfer money to a Savings or Credit account
     * 
     * @param savingAcc
     * @param checkingAcc
     * @param creditAcc
     * @param amount
     * @param decision
     */
    @Override
    public void transfer(Saving savingAcc, Checking checkingAcc, Credit creditAcc, double amount, int decision) {
        switch (decision) {
        case 1:
            if (amount < checkingAcc.getBalance()) {
                double newBalance1 = checkingAcc.getBalance() - amount;
                double newBalance2 = savingAcc.getBalance() + amount;
                checkingAcc.setBalance(newBalance1);
                savingAcc.setBalance(newBalance2);
            } else
                System.out.println("Please try the transaction again");
            break;

        case 2:
            boolean overPaid = creditAcc.isOverpaid(amount);

            if (amount < checkingAcc.getBalance() || overPaid == false) {
                double newBalance1 = checkingAcc.getBalance() - amount;
                double newBalance2 = creditAcc.getBalance() + amount;
                checkingAcc.setBalance(newBalance1);
                creditAcc.setBalance(newBalance2);
            }else
                System.out.println("Please try the transaction again");
            break;
        }// end of switch
    }// end of transfer

    /**
     * Method that tells the user the balance of the account
     */
    @Override
    public void inquire() {
        System.out.println("\nYour Checkings balance is " + getBalance());
    }

    /**
     * method that updates the balance with the amount entered.
     * 
     * @param amount
     */
    @Override
    public void deposit(double amount) {
        setBalance(getBalance() + amount);
    }
}// end of class
