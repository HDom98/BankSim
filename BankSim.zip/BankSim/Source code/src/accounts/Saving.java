package accounts;

public class Saving extends Account {

    /**
     * Constructor
     * 
     * @param accountNum
     * @param balance
     */
    public Saving(int accountNum, double balance) {
        super(accountNum, balance);
    }// end of constructor

    /**
     * Method that allows the user to transfer money to a Checking or Credit account
     * 
     * @param savingAcc
     * @param checkingAcc
     * @param creditAcc
     * @param amount
     * @param decision
     */
    public void transfer(Saving savingAcc, Checking checkingAcc, Credit creditAcc, double amount, int decision) {
        switch (decision) {
        case 1:
            if (amount < savingAcc.getBalance()) {
                double newBalance1 = savingAcc.getBalance() - amount;
                double newBalance2 = checkingAcc.getBalance() + amount;
                savingAcc.setBalance(newBalance1);
                checkingAcc.setBalance(newBalance2);
            } else
                System.out.println("Please try the transaction again");
            break;

        case 2:
            if (amount < savingAcc.getBalance() && creditAcc.isOverpaid(amount) == false) {
                double newBalance1 = savingAcc.getBalance() - amount;
                double newBalance2 = creditAcc.getBalance() + amount;
                savingAcc.setBalance(newBalance1);
                creditAcc.setBalance(newBalance2);
            } else
                System.out.println("Please try the transaction again");
            break;
        }// end of switch
    }// end of transfer

    /**
     * Method that tells the user the balance of the account
     */
    @Override
    public void inquire() {
        System.out.println("\nYour Savings balance is " + getBalance());
    }

    /**
     * Method that updates the balance with the amount entered.
     * 
     * @param amount
     */
    @Override
    public void deposit(double amount) {
        setBalance(getBalance() + amount);
    }
}// end of class
