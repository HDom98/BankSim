
/*
Hugo Dominguez
Robin
October 24, 2019
CS 3331
Daniel Mejia
Checking account project
a program that reads a text file and allows the user to inquire,deposit,withdraw,and pay someone using 
the text file.

I confirm that the work of this assignment is completely my own. By turning in this assignment, 
I declare that I did not receive unauthorized assistance. Moreover, all deliverables including, 
but not limited to the source code, lab report, and output files were written and produced by me alone.
*/
import java.io.*;
import java.util.*;

import log.*;
import accounts.*;
import people.*;

public class runBank {

	/**
	 * main method. User chooses between customer transaction or a manager
	 * transaction. when the user exits out an updated transaction log is created
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		ArrayList<Customer> customers = readFile();
		Scanner keyboard = new Scanner(System.in);
		Boolean start = true;

		System.out.println("Welcome to the Bank");
		while (start == true) {
			try {
				System.out.println("press 1 for returning customer\n" + "2 for manager");
				int decision = keyboard.nextInt();
				// calls the customerTransaction method to do transactions as a customer
				if (decision == 1) {
					customerTransaction(customers);
					System.out.println("Would you like to exit? 1 for yes, 2 for no");
					decision = keyboard.nextInt();
					if (decision == 1)
						start = false;
				} // end of if

				// calls managerTransaction to do transactions as a manager
				else if (decision == 2) {
					managerTransaction(customers);
					System.out.println("Would you like to exit? 1 for yes, 2 for no");
					decision = keyboard.nextInt();
					if (decision == 1)
						start = false;
				} // end of else if
				else
					System.out.println("incorrect input please try again");

			} catch (InputMismatchException e) {
				System.out.println("incorrect input please try again");
			} // end of catch
		} // end of while
		keyboard.close();
		// insert update transaction
		File file = new File("Updated balance sheet.csv");
		PrintWriter pw = new PrintWriter(new FileWriter(file, false));
		for(Customer c: customers){
			pw.println(c.print());
		}
		pw.close();
	}// end of main

	/**
	 * Method that reads
	 * 
	 * @return ArrayList<Customer> customerList
	 * @throws FileNotFoundException
	 */
	public static ArrayList<Customer> readFile() throws FileNotFoundException {

		int firstNameIndex;
		int lastNameIndex;
		int dobIndex;
		int idIndex;
		int addressIndex;
		int phoneNumIndex;
		int checkingAccNumIndex;
		int savingsAccNumIndex;
		int creditAccNumIndex;
		int checkingBalanceIndex;
		int savingsBalanceIndex;
		int creditBalanceIndex;

		String firstName;
		String lastName;
		String dob;
		String id;
		String address;
		String phoneNum;
		int checkingsAccNum;
		int savingsAccNum;
		int creditAccNum;
		double checkingsBalance;
		double savingsBalance;
		double creditBalance;

		// creating an array list to hold everything read from the file
		ArrayList<Customer> customerList = new ArrayList<Customer>();

		// open and read the file.
		Scanner accountReader = new Scanner(
				new File("CS 3331 - Bank Users 3a.txt"));
		
		// reads first line and stores it in an array
		String [] line = accountReader.nextLine().split("\t");

		//finding the index of all the variables in the Customer object
		firstNameIndex = findPosition(line,"First Name");
		lastNameIndex = findPosition(line,"Last Name");
		dobIndex = findPosition(line,"Date of Birth");
		idIndex = findPosition(line,"Identification Number");
		addressIndex = findPosition(line,"Address");
		phoneNumIndex = findPosition(line,"Phone Number");
		checkingAccNumIndex = findPosition(line,"Checking Account Number");
		savingsAccNumIndex = findPosition(line,"Savings Account Number");
		creditAccNumIndex = findPosition(line,"Credit Account Number");
		checkingBalanceIndex = findPosition(line,"Checking Starting Balance");
		savingsBalanceIndex = findPosition(line,"Savings Starting Balance");
		creditBalanceIndex = findPosition(line,"Credit Starting Balance");

		
		//loop that initializes all the variables read
		while(accountReader.hasNextLine()){
			line = accountReader.nextLine().split("\t");
			firstName = line[firstNameIndex];
			lastName = line[lastNameIndex];
			dob =line[dobIndex];
			id = line[idIndex];
			address = line[addressIndex];
			phoneNum = line[phoneNumIndex];
			checkingsAccNum = Integer.parseInt(line[checkingAccNumIndex]);
			savingsAccNum = Integer.parseInt(line[savingsAccNumIndex]);
			creditAccNum = Integer.parseInt(line[creditAccNumIndex]);
			checkingsBalance = Double.parseDouble(line[checkingBalanceIndex]);
			savingsBalance = Double.parseDouble(line[savingsBalanceIndex]);
			creditBalance = Double.parseDouble(line[creditBalanceIndex]);

			Checking checkingAcc = new Checking(checkingsAccNum, checkingsBalance);
			Saving savingAcc = new Saving(savingsAccNum, savingsBalance);
			Credit creditAcc = new Credit(creditAccNum, creditBalance);
			customerList.add(
			new Customer(firstName, lastName, dob, id, address, phoneNum, checkingAcc, savingAcc, creditAcc));
			System.out.println("First Name: "+firstName);
			System.out.println("Last Name: "+lastName);
			System.out.println("Date of Birth: "+dob);
			System.out.println("ID: "+id);
			System.out.println("Address: "+address);
			System.out.println("Phone Number: "+phoneNum);
			System.out.println("Checking account number: "+checkingsAccNum);
			System.out.println("Checking balance: "+checkingsBalance);
			System.out.println("Savings account Number: "+savingsAccNum);
			System.out.println("Savings balance: "+savingsBalance);
			System.out.println("Credit account number: "+creditAccNum);
			System.out.println("Credit balance: "+creditBalance);

		}
		accountReader.close();
		return customerList;
	}// end of readFile


	public static int findPosition(String[] line, String variable){
		for(int i =0; i < line.length; i++) {
			if(line[i].equalsIgnoreCase(variable))
				return i;
		}
		return 1;
	}
	/**
	 * Method that goes through all the transactions a customer can do. Allows for
	 * user to choose between transactions transaction log is updated everytime the
	 * user does a transaction
	 * 
	 * @param customers
	 * @throws IOException
	 */
	public static void customerTransaction(ArrayList<Customer> customers) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		boolean loop = true;
		int choice;

		// assuming there are no duplicate names
		System.out.println("Please enter your first name");
		String firstName = keyboard.nextLine();
		Customer currentCustomer = findCustomer(customers, firstName);
		while (loop == true) {

			if (currentCustomer.getFirstName().equals(firstName)) {
				System.out
						.println("press 1 to inquire your balance\n" + "press 2 to deposit\n" + "press 3 to withdraw\n"
								+ "press 4 to pay someone\n" + "press 5 to transfer money\n" + "press 6 to exit");
				choice = keyboard.nextInt();

				switch (choice) {
				case 1:
					LogInquire logI = new LogInquire();
					System.out.println("Which account balance would you like to inquire a balance?\n"
							+ "press 1 for checkings\n" + "press 2 for savings\n" + "press 3 for credit");
					choice = keyboard.nextInt();
					if (choice == 1) {
						currentCustomer.checkingAcc.inquire();
						logI.writeLog(currentCustomer, choice);
					} else if (choice == 2) {
						currentCustomer.savingsAcc.inquire();
						logI.writeLog(currentCustomer, choice);
					} else if (choice == 3) {
						currentCustomer.creditAcc.inquire();
						logI.writeLog(currentCustomer, choice);
					} else
						System.out.println("invalid entry please try again");

					break;

				case 2:
					LogDeposits logD = new LogDeposits();
					System.out.println("Which account balance would you like to deposit to?\n"
							+ "press 1 for checkings\n" + "press 2 for savings\n" + "press 3 for credit");
					choice = keyboard.nextInt();

					if (choice == 1) {
						System.out.println("Please enter the amount you would like to deposit");
						double amount = keyboard.nextDouble();
						currentCustomer.checkingAcc.deposit(amount);
						logD.writeLog(currentCustomer, amount, choice);
					}

					else if (choice == 2) {
						System.out.println("Please enter the amount you would like to deposit");
						double amount = keyboard.nextDouble();
						currentCustomer.savingsAcc.deposit(amount);
						logD.writeLog(currentCustomer, amount, choice);
					}

					else if (choice == 3) {
						System.out.println("Please enter the amount you would like to deposit");
						double amount = keyboard.nextDouble();
						currentCustomer.creditAcc.deposit(amount);
						logD.writeLog(currentCustomer, amount, choice);
					}

					else
						System.out.println("invalid entry please try again");
					break;

				// assuming you can only withdraw from a checking account
				case 3:
					System.out.println("Please enter the amount you would like to withdraw");
					double amount = keyboard.nextDouble();

					currentCustomer.checkingAcc.withdraw(amount);

					LogWithdraw logW = new LogWithdraw();
					logW.writeLog(currentCustomer, amount);
					break;

				// again assuming there are no duplicates
				case 4:

					keyboard.nextLine();
					System.out.println("Enter the first name of the person you would like to pay");
					String personName2 = keyboard.nextLine();

					Customer person2 = findCustomer(customers, personName2);
					if (!person2.getFirstName().equals(currentCustomer.getFirstName())) {
					System.out.println("Please enter the amount you would like to pay to " + person2.getFirstName());
						amount = keyboard.nextDouble();
						person2.payPerson(currentCustomer, person2, amount);

						LogPay logP = new LogPay();
						logP.writeLog(currentCustomer, person2, amount);
					} else
						System.out.println("incorrect Name please try again");
					break;

				case 5:
					LogTransfer logT = new LogTransfer();
					System.out.println("Which account balance would you like to transfer money from?\n"
							+ "press 1 for checkings\n" + "press 2 for savings\n" + "press 3 for credit");
					choice = keyboard.nextInt();

					if (choice == 1) {
						System.out.println(
								"Which account would you like to transfer to?\n" + "1 for Savings\n" + "2 for Credit");
						choice = keyboard.nextInt();
						keyboard.nextLine();

						System.out.println("Enter the amount you would like to transfer");
						amount = keyboard.nextDouble();

						currentCustomer.checkingAcc.transfer(currentCustomer.savingsAcc, currentCustomer.checkingAcc,
								currentCustomer.creditAcc, amount, choice);

						logT.writeLog(currentCustomer, amount, choice);
					} else if (choice == 2) {
						System.out.println(
								"Which account would you like to transfer to?\n" + "1 for Checking\n" + "2 for Credit");
						choice = keyboard.nextInt();
						keyboard.nextLine();

						System.out.println("Enter the amount you would like to transfer");
						amount = keyboard.nextDouble();

						currentCustomer.savingsAcc.transfer(currentCustomer.savingsAcc, currentCustomer.checkingAcc,
								currentCustomer.creditAcc, amount, choice);

						logT.writeLog(currentCustomer, amount, choice + 2);
					} else if (choice == 3) {
						System.out.println("Which account would you like to transfer to?\n" + "1 for Checking\n"
								+ "2 for Savings");
						choice = keyboard.nextInt();
						keyboard.nextLine();

						System.out.println("Enter the amount you would like to transfer");
						amount = keyboard.nextDouble();

						currentCustomer.creditAcc.transfer(currentCustomer.savingsAcc, currentCustomer.checkingAcc,
								currentCustomer.creditAcc, amount, choice);
						logT.writeLog(currentCustomer, amount, choice + 4);
					} else
						System.out.println("invalid entry please try again");
					break;

				case 6:
					System.out.println("Goodbye " + currentCustomer.getFirstName());
					loop = false;
					break;
				}// end of switch

			} // end of if
			else {
				System.out.println("Name not found please try again");
				loop = false;
			} // end of else
		} // end of while
	}// end of customerTransaction

	/**
	 * Method that goes through an ArrayList of Customers and locates the customer
	 * based on their name
	 * 
	 * @param customers
	 * @param name
	 * @return customer
	 */
	public static Customer findCustomer(ArrayList<Customer> customers, String name) {

		for (Customer c : customers) {
			if (c.getFirstName() != null && c.getFirstName().contains(name) || c.getFirstName().contentEquals(name)) {
				return c;
			} // end of if
		} // end of for
		Customer notFound = new Customer("not found", "not found", null, null, null, null, null, null, null);
		return notFound;
	}// end of findCustomer

	/**
	 * Method that goes through an ArrayList of Customers and locates a customers
	 * account based on their account number
	 * 
	 * @param customers
	 * @param name
	 * @return customer
	 */
	public static Customer findAccount(ArrayList<Customer> customers, int accountNum, int choice) {
		for (Customer c : customers) {
			if (choice == 1 && c.checkingAcc.getAccountNum() == accountNum) {
				return c;
			} // end of if
			else if (choice == 2 && c.savingsAcc.getAccountNum() == accountNum) {
				return c;
			} else if (choice == 3 && c.creditAcc.getAccountNum() == accountNum) {
				return c;
			}
		} // end of for
		Customer notFound = new Customer("not found", "not found", null, null, null, null, null, null, null);
		return notFound;
	}// end of findCustomer

	/**
	 * Method that allows the bank manager to inquire all of a customers accounts, a
	 * specific account, or all the accounts available in the ArrayList
	 * 
	 * @param customers
	 * @throws IOException
	 */
	public static void managerTransaction(ArrayList<Customer> customers) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		LogInquire log = new LogInquire();

		System.out.println(
				"1 to inquire by name\n" + "2 to inquire by type and account number\n" + "3 to inquire all accounts");
		int choice = keyboard.nextInt();

		switch (choice) {
		case 1:
			keyboard.nextLine();
			System.out.println("Who's account would you like to inquire about?");
			String name = keyboard.nextLine();
			Customer currentCustomer = findCustomer(customers, name);
			if (currentCustomer.getFirstName().equalsIgnoreCase(name)) {
				currentCustomer.checkingAcc.inquire();
				currentCustomer.savingsAcc.inquire();
				currentCustomer.creditAcc.inquire();
				log.writeLog(currentCustomer, 0, 4);
			} else
				System.out.println("Name not found please try again");
			break;

		case 2:
			System.out.println("1 for checkings\n" + "2 for savings\n" + "3 for credit");
			choice = keyboard.nextInt();
			System.out.println("Please enter the Account Number");
			int accountNum = keyboard.nextInt();
			currentCustomer = findAccount(customers, accountNum, choice);
			if (choice == 1 && currentCustomer.checkingAcc.getAccountNum() == accountNum) {
				currentCustomer.checkingAcc.inquire();
				log.writeLog(currentCustomer, 4);
			} else if (choice == 2 && currentCustomer.savingsAcc.getAccountNum() == accountNum) {
				currentCustomer.savingsAcc.inquire();
				log.writeLog(currentCustomer, 4);
			} else if (choice == 3 && currentCustomer.creditAcc.getAccountNum() == accountNum) {
				currentCustomer.creditAcc.inquire();
				log.writeLog(currentCustomer, 4);
			}
			break;

		case 3:
			for (Customer c : customers) {
				System.out.println(
						c.getFirstName() + "'s Checking balance: " + c.checkingAcc.getBalance() + " Savings balance:"
								+ c.savingsAcc.getBalance() + " Credit balance:" + c.creditAcc.getBalance() + "\n");
				log.writeLog(c, 4);
			}
			break;
		}// end of switch
	}// end of manager
}// end of runBank